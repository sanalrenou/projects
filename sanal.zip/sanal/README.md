## Neighbourhood Map project for Udacity Nanodegree Program
------------------------------------------------------------

## About the project

**Neighbourhood Map** is the neighbour locations of New Delhi City 
 which shows  all  the tourist locations in New Delhi and nearby  
 from google maps and also gets image,review and rating of that
 place from Foursquare.

-----------------------------------------------------------------------

## Libraries used
- [knockoutjs](http://knockoutjs.com/).

------------------------------------------------------------
## Api's used
- Google Maps.
- Foursquare.

-------------------------------------------------------------
- Live url https://sanalproject.000webhost.com/
                (or)
- Download the file and open index.html to run locally.

---------------------------------------------------------------

